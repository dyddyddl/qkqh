package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;

import model.bean.MemberBean;

/**
 * Servlet implementation class LoginProcessServlet
 */
public class LoginProcessServlet_0220 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		MemberBean bean = new MemberBean();
		bean.setId("kim123");
		bean.setAddr("서울시 송파구");
		bean.setCartCount(12);
		bean.setPw("789");
		bean.setNickName("말자");
		
		MemberBean bean2 = new MemberBean();
		bean2.setId("Park@dd.fda");
		bean2.setAddr("서울시 강남구");
		bean2.setCartCount(16);
		bean2.setPw("123");
		bean2.setNickName("베니");
		
		MemberBean bean3 = new MemberBean();
		bean3.setId("lee");
		bean3.setAddr("서울시 양천구");
		bean3.setCartCount(2);
		bean3.setPw("456");
		bean3.setNickName("ㅂㅏㅁ비");
		
		List<MemberBean> members = new ArrayList<MemberBean>();
		
		members.add(bean);
		members.add(bean2);
		members.add(bean3);
		
		String id = request.getParameter("id").trim();
		String pw = request.getParameter("pw").trim();
		
		
		HttpSession session = null;
		
		for(MemberBean member : members ) {
			if(member.getId().equals(id)  &&  member.getPw().equals(pw)) {
				request.setAttribute("member", member);

				session = request.getSession(true);
				String nextPage = "/jstlTest2_1.jsp";
				System.out.println("session.isNew()???"+session);
			
				if(session.isNew()) {
					session.setMaxInactiveInterval(60);
					session.setAttribute("user", member);
					nextPage = "/welcome";
				}
				request.getRequestDispatcher(nextPage).forward(request, response); // 어디로보냄
				break;
			
			
		}
		//request.getRequestDispatcher("/fail").forward(request, response);
		}
		
	}
	}


