
package controller;



import java.io.IOException;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;



import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;



import org.apache.catalina.Session;



import model.bean.MemberBean;



/**

 * Servlet implementation class LoginProcessServlet

 */

public class LoginProcessServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;



	/**

	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse

	 *      response)

	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)

			throws ServletException, IOException {

		// TODO Auto-generated method stub

		Connection conn = null;

		PreparedStatement pState = null;

		ResultSet resultSet = null;



		String id = request.getParameter("id").trim();

		String pw = request.getParameter("pw").trim();

		HttpSession session = null;

		String nextPage;

		// DB에 접속

		try {

			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();

			conn = DriverManager.getConnection(

					
			
					"jdbc:mysql://localhost/sample?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",

					"root", "a123456789");

			String sql = "  select     nickName,  cartCount         from    member      where   id=?  and pw=?   ";// member

																													// table에서

																													// 장바구니에

																													// 5개이상인

																													// 멤버목록(해당되는

																													// 사람들),

			pState = conn.prepareStatement(sql);

			pState.setString(1, id);

			pState.setString(2, pw);

			resultSet = pState.executeQuery();



			if (resultSet.next()) { // 아이디와 암호 일치하는 사람이 있다.

				MemberBean member = new MemberBean();

				member.setId(id);

				member.setNickName(resultSet.getString("nickName"));

				member.setCartCount(resultSet.getInt("cartCount"));

				// sesssion

				session = request.getSession();

				if (!session.isNew()) {

					session.invalidate();

					session = request.getSession(true);

				}

				request.setAttribute("member", member);

				session.setMaxInactiveInterval(60);

				session.setAttribute("user", member);

				request.getRequestDispatcher("/welcome").forward(request, response);
			} else {
				nextPage = "/fail";
				response.sendRedirect(nextPage);

			}



		} catch (InstantiationException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (IllegalAccessException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (ClassNotFoundException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}



	



		/*

		 * for( MemberBean member : members ) { if(member.getId().equals( id) &&

		 * member.getPw().equals(pw) ) {

		 * 

		 * session = request.getSession();

		 * 

		 * System.out.println("session =="+session); if(!session.isNew()) {

		 * session.invalidate(); session = request.getSession(true); }

		 * request.setAttribute("member", member); session.setMaxInactiveInterval(60);

		 * session.setAttribute("user", member); nextPage= "/welcome";

		 * 

		 * 

		 * 

		 * 

		 * 

		 * request.getRequestDispatcher(nextPage).forward(request, response); break;

		 * //System.out.println("6666666"); } }

		 * 

		 * if(session ==null) { response.sendRedirect("/loginFail.jsp"); }

		 */



	}



}

/*
 * package controller;
 * 
 * import java.io.IOException; import java.sql.Connection; import
 * java.sql.DriverManager; import java.sql.PreparedStatement; import
 * java.sql.ResultSet; import java.sql.SQLException; import java.util.ArrayList;
 * import java.util.List;
 * 
 * import javax.servlet.ServletException; import javax.servlet.http.HttpServlet;
 * import javax.servlet.http.HttpServletRequest; import
 * javax.servlet.http.HttpServletResponse; import
 * javax.servlet.http.HttpSession;
 * 
 * import org.apache.catalina.Session;
 * 
 * import model.bean.MemberBean;
 * 
 *//**
	 * Servlet implementation class LoginProcessServlet
	 */
/*
 * public class LoginProcessServlet extends HttpServlet { private static final
 * long serialVersionUID = 1L;
 * 
 *//**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 *//*
		 * protected void doPost(HttpServletRequest request, HttpServletResponse
		 * response) throws ServletException, IOException { // TODO Auto-generated
		 * method stub //MemberBean bean = new MemberBean();
		 * 
		 * Connection conn = null; PreparedStatement pState=null;
		 * 
		 * String id = request.getParameter("id").trim(); String pw =
		 * request.getParameter("pw").trim(); HttpSession session = HttpSession();
		 * 
		 * //DB에 접속 try { Class.forName("com.mysql.cj.jdbc.Driver").newInstance(); try {
		 * conn = DriverManager.getConnection(
		 * "jdbc:mysql://localhost/sample?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
		 * "root", "a123456789");
		 * 
		 * String sql =
		 * "select		id,nickName,addr,cartCount			from      member 		where 	id=? and pw =?"
		 * ; //member table에서 장바구니에 5개 이상인 멤버 목록(해당되는 사람들), 닉네임 pState =
		 * conn.prepareStatement(sql); pState.setString(1, id); pState.setString(2,pw);
		 * ResultSet resultSet = null; resultSet = pState.executeQuery();
		 * 
		 * if(resultSet.next()) { MemberBean member = new MemberBean();
		 * member.setId(id); member.setNickName(resultSet.getString("nickName"));
		 * member.setCartCount(resultSet.getInt("cartCount")); //session
		 * 
		 * session = request.getSession();
		 * 
		 * }else {
		 * 
		 * }
		 * 
		 * } catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } } catch (InstantiationException e) {
		 * e.printStackTrace(); } catch (IllegalAccessException e) {
		 * e.printStackTrace(); } catch (ClassNotFoundException e) {
		 * e.printStackTrace(); }
		 * 
		 * HttpSession session = null; String nextPage;
		 * 
		 * 
		 * 
		 * 
		 * 
		 * for(MemberBean member : members ) { if(member.getId().equals(id) &&
		 * member.getPw().equals(pw)) { request.setAttribute("member", member);
		 * 
		 * session = request.getSession(true); String nextPage = "/jstlTest2_1.jsp";
		 * System.out.println("session.isNew()???"+session);
		 * 
		 * if(session.isNew()) { session.setMaxInactiveInterval(60);
		 * session.setAttribute("user", member); nextPage = "/welcome"; }
		 * request.getRequestDispatcher(nextPage).forward(request, response); // 어디로보냄
		 * break;
		 * 
		 * 
		 * } //request.getRequestDispatcher("/fail").forward(request, response); }
		 * 
		 * 
		 * 
		 */

