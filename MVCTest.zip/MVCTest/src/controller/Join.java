package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.bean.MemberBean;

/**
 * Servlet implementation class Join
 */
public class Join extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id").trim();

		String pw = request.getParameter("pw").trim();
		
		String nickName = request.getParameter("nickName").trim();
	
		String addr = request.getParameter("addr").trim();
	
		String birthDate = request.getParameter("birthDate").trim();
	
		Connection conn = null;

		PreparedStatement pState = null;

		ResultSet resultSet = null;
		
		HttpSession session = null;

		String nextPage;
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			
			conn = DriverManager.getConnection(

					"jdbc:mysql://localhost/sample?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",

					"root", "a123456789");
			
			String sql = "  select     nickName,  cartCount         from    member      where   id=?  and pw=?   ";// 대조

			pState = conn.prepareStatement(sql);
			pState.setString(1, id);
			
			// resultSet = pState.executeQuery("select * from test" ); ResulSet은 executeQuery( ) 메소드에서 실행된 select 문의 결과값을 가지고 있는 객체입니다.
			
			if (!resultSet.next()) { // 아이디 일치하는 사람이 없다

				MemberBean member = new MemberBean();

				member.setId(id); //아이디

				member.setNickName(resultSet.getString("nickName")); //닉네임
 
				member.setPw((resultSet.getString("pw")));  //암호
				
				member.setAddr(resultSet.getString("addr")); //주소
				
				
				

				// sesssion

				session = request.getSession();

				if (!session.isNew()) {

					session.invalidate();

					session = request.getSession(true);

				}

				request.setAttribute("member", member);

				session.setMaxInactiveInterval(60);

				session.setAttribute("user", member);

				request.getRequestDispatcher("/welcome").forward(request, response);
			} else {
				nextPage = "/fail";
				response.sendRedirect(nextPage);

			}



		}  catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	}

}
