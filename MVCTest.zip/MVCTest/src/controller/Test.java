package controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.MemberBean;

/**
 * Servlet implementation class Test
 */
public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		MemberBean bean = new MemberBean();
		bean.setId("kim123");
		bean.setAddr("서울시 송파구");
		bean.setCartCount(12);
		bean.setPw("789");
		bean.setNickName("말자");
		
		MemberBean bean2 = new MemberBean();
		bean2.setId("Park@dd.fda");
		bean2.setAddr("서울시 강남구");
		bean2.setCartCount(16);
		bean2.setPw("123");
		bean2.setNickName("베니");
		
		MemberBean bean3 = new MemberBean();
		bean3.setId("lee");
		bean3.setAddr("서울시 양천구");
		bean3.setCartCount(2);
		bean3.setPw("456");
		bean3.setNickName("ㅂㅏㅁ비");
		
		request.setAttribute("member", bean);
		request.setAttribute("member2", bean2);
		request.setAttribute("member3", bean3);
		
	//	List<MemberBean>members = new ArrayList<MemberBean>();

		List<MemberBean> members = new ArrayList<MemberBean>();
		
		members.add(bean);
		members.add(bean2);
		members.add(null);
		members.add(bean3);
		
		request.setAttribute("members", members);
		
		HashMap<String, MemberBean> memberMap = new HashMap<String, MemberBean>();
		memberMap.put("Gold",bean3);
		memberMap.put("Silver",bean2);
		request.setAttribute("memberMap", memberMap);
//		request.getRequestDispatcher("elTest.jsp").forward(request, response);
		request.getRequestDispatcher("jstlTest2.jsp").forward(request, response);
	

	}

}
