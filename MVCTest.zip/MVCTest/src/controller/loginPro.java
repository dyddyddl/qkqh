package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginPro
 */
public class loginPro extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		String id = request.getParameter("id");
		String passwd = request.getParameter("passwd");
		if(id.equals("kim12345") && passwd.equals("123")) { // jsp는 자동적으로 session을 생성한다. 세션이 생성됐는지 확인하는 명령
			if(!session.isNew()) {
				session = request.getSession(true);
			}
			session.setMaxInactiveInterval(3*60);
			session.setAttribute("id", id);
		RequestDispatcher rd = request.getRequestDispatcher("/loginSuccess123");
		rd.forward(request, response);

		//jsp:forward padge = "loginSuccess.jsp"/>
		}else {
			System.out.println("ID와 Password를 확인하시기 바랍니다.");
			RequestDispatcher rd2 = request.getRequestDispatcher("/login123");
			rd2.forward(request, response);
		}
	}

}
