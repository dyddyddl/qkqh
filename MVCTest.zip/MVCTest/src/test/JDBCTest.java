package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// MySql Driver load
		Connection conn = null;
		PreparedStatement pState=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			System.out.println("Driver load!");

			conn = DriverManager.getConnection(

					"jdbc:mysql://localhost/sample?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "a123456789");

			// conn = DriverManager.getConnection("jdbc:mysql://localhost/sample" ,"root"
			// ,"a123456789" );
			System.out.println("conn :  성공");
			
			String sql = "select		id,nickName,addr,cartCount			from      member 		where 	cartCount >?	"; //member table에서 장바구니에 5개 이상인 멤버 목록(해당되는 사람들), 닉네임 
			pState = conn.prepareStatement(sql);
			pState.setInt(1, 5);
			ResultSet resultSet = null;
			resultSet = 	pState.executeQuery();
	
			while(resultSet.next()) {
				System.out.print(resultSet.getString("id")+","+resultSet.getInt("cartCount"));
			}
			
			//System.out.println(resultSet.next());
			
			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
